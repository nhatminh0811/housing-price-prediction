# Vietnam House Price Prediction Web App

This is a web application that predicts house prices in Vietnam based on various features using a machine learning model.

## Setup Instructions

1. Make sure you have Python 3.8+ installed on your system.

2. Install the required dependencies:
```bash
pip install -r requirements.txt
```

3. Make sure the model file `house_price_pipeline.joblib` is in the root directory.

4. Run the application:
```bash
python app.py
```

5. Open your web browser and navigate to `http://localhost:5000`

## Usage

1. Fill in all the required fields in the form:
   - Address
   - Area (in square meters)
   - Access Road Width (in meters)
   - House Direction
   - Balcony Direction
   - Number of Floors
   - Number of Bedrooms
   - Number of Bathrooms
   - Legal Status
   - Furniture State

2. Click the "Predict Price" button

3. The predicted price will be shown in billion VND

## Features

- Modern, responsive user interface
- Real-time price predictions
- Error handling and validation
- Support for Vietnamese addresses and directions 