from joblib import load
import pandas as pd

# Load the trained pipeline
model = load("house_price_pipeline.joblib")

# Example input (must match training data format)
input_data = {
    "Address": ["Đường Nguyễn Văn Khối, Phường 11, Gò Vấp, Hồ Chí Minh"],
    "Area": [54.0],
    "Frontage": [None],  # Will be imputed
    "Access Road": [3.5],
    "House direction": ["Tây - Nam"],
    "Balcony direction": ["Tây - Nam"],
    "Floors": [2.0],
    "Bedrooms": [2.0],
    "Bathrooms": [3.0],
    "Legal status": ["Have certificate"],
    "Furniture state": ["Full"]
}

# Convert to DataFrame (important for the pipeline)
input_df = pd.DataFrame(input_data)

# Predict
predicted_price = model.predict(input_df)
print(f"Predicted Price: {predicted_price[0]:.2f} billion VND")