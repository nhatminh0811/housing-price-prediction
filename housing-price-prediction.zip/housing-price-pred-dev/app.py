from flask import Flask, render_template, request, jsonify
from joblib import load
import pandas as pd
import os
import sys

app = Flask(__name__)

# Define paths
MODEL_PATH = os.path.join('models', 'house_price_pipeline.joblib')

# Load the trained model
try:
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model file not found at {MODEL_PATH}")
    model = load(MODEL_PATH)
except Exception as e:
    print(f"Error loading model: {str(e)}", file=sys.stderr)
    sys.exit(1)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get frontage value, default to None if not provided
        frontage = request.form.get('frontage')
        frontage = float(frontage) if frontage else None

        data = {
            "Address": [request.form.get('address')],
            "Area": [float(request.form.get('area'))],
            "Frontage": [frontage],  # Will be imputed if None
            "Access Road": [float(request.form.get('access_road'))],
            "House direction": [request.form.get('house_direction')],
            "Balcony direction": [request.form.get('balcony_direction')],
            "Floors": [float(request.form.get('floors'))],
            "Bedrooms": [float(request.form.get('bedrooms'))],
            "Bathrooms": [float(request.form.get('bathrooms'))],
            "Legal status": [request.form.get('legal_status')],
            "Furniture state": [request.form.get('furniture_state')]
        }
        
        input_df = pd.DataFrame(data)
        prediction = model.predict(input_df)
        
        return jsonify({
            'success': True,
            'prediction': f"{prediction[0]:.2f}"
        })
    except ValueError as e:
        return jsonify({
            'success': False,
            'error': f"Invalid input data: {str(e)}"
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f"An error occurred: {str(e)}"
        })

if __name__ == '__main__':
    app.run(debug=True) 